let rbtn = document.querySelector('#right-btn');
let lbtn = document.querySelector('#left-btn');
let pictures = document.querySelectorAll('.slider-images img');
let imgNum = 0;


rbtn.addEventListener('click', () =>{
    displaynone();
    imgNum++;

    if(imgNum === pictures.length){
        imgNum = 0;
    }

    pictures[imgNum].style.display = 'block';
});

lbtn.addEventListener('click',() => {
    displaynone();
    imgNum--;

    if(imgNum === -1){
        imgNum = pictures.length - 1;
    }
    pictures[imgNum].style.display = 'block';

});




const displaynone = () => {
    pictures.forEach((img) => {
        img.style.display = 'none';
    })
}